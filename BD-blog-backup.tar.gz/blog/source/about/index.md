---
title: 关于
date: 2026-07-17 19:20:00
---

## 关于我

这是一个关于技术、设计和创意的个人博客。

在这里，我会分享：

- 技术文章和教程
- 设计灵感和作品
- 创意想法和项目

## 联系方式

- GitHub: [your-github](https://github.com/xxxxxx)
- Email: your-email@example.com

## 关于本站

本站使用 [Hexo](https://hexo.io/) 搭建，采用 [Butterfly](https://github.com/jerryc127/hexo-theme-butterfly) 主题。
