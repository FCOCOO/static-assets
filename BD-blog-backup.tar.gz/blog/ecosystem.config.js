module.exports = {
  apps: [{
    name: 'zenith',
    script: 'hexo',
    args: 'server',
    cwd: '/home/yi/桌面/BD/blog',
    env: {
      NODE_ENV: 'development',
    }
  }]
};
